package com.example.common_fig.Bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.common_fig.R;
import com.example.common_fig.Permission;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Bluetooth_setting extends AppCompatActivity {

    BluetoothAdapter mBluetoothAdapter;
    BluetoothLeScanner mBluetoothLeScanner;
    ArrayList<String> DeviceAddresslist;
    ArrayList<Map<String,Object>> SimpleAdapterData;
    SimpleAdapter mAdapter;
    Handler mHandler;
    boolean mScanning;
    final private int SCANNING_TIME=10000;
    final static public int BLUETOOTHDEVICE_RESULT=0;
    final static public String DEVICE_NAME="DEVICE_NAME";
    final static public String DEVICE_ADDRESS="DEVICE_ADDRESS";
    final static public String CONNECT_STATE="connect_state";
    final private String[] Adapteritem= new String[]{"Device_imageView","Device_name","Device_address"};
    final private int[] AdapterView=new int[]{R.id.Device_imageView,R.id.Device_name,R.id.Device_address};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //设置标题栏
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            //设置返回键,在Manifest设置父活动
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        //初始化蓝牙配置
        Bluetooth_init();
        //初始化界面配置
        View_init();
        //初始化Handler
        mHandler=new Handler();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case android.R.id.home:
                finish();
                return false;
        }
        return super.onOptionsItemSelected(item);
    }

    private void Bluetooth_init(){
        //检测是否有蓝牙
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "Bluetooth not found!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        // 初始化一个蓝牙适配器
        final BluetoothManager bluetoothManager=(BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        //  检查设备是否支持蓝牙
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Failed to access Bluetooth device!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        mBluetoothLeScanner=mBluetoothAdapter.getBluetoothLeScanner();
        mScanning=false;
        Setprogressbar();
        //申请位置权限
        Permission.veritfyPositionPermissions(this);
    }

    private void View_init(){
        DeviceAddresslist=new ArrayList<>();
        SimpleAdapterData=new ArrayList<>();
        mAdapter=new SimpleAdapter(getApplicationContext(),SimpleAdapterData,
                R.layout.madapter_layout,Adapteritem,AdapterView);
        ListView list=findViewById(R.id.bluetooth_device_list);
        list.setAdapter(mAdapter);
        //配置监听器
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(mScanning){
                    mBluetoothLeScanner.stopScan(mLeScanCallback);
                    mScanning=false;
                    Setprogressbar();
                }
                String device=DeviceAddresslist.get(position);
                Intent intent=new Intent();
                //intent.putExtra(DEVICE_NAME, device.getName());
                intent.putExtra(DEVICE_ADDRESS,device);
                setResult(BLUETOOTHDEVICE_RESULT,intent);
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 0);
        }
        Scan_Device();
    }

    public void Onclick_scanningrefresh(View v){
        Device_clear();
        Scan_Device();
    }

    private void Scan_Device(){
        //未打开蓝牙，直接返回
        if(!mBluetoothAdapter.isEnabled()) {
            Toast.makeText(getApplicationContext(),"Bluetooth off!",Toast.LENGTH_SHORT).show();
            return;
        }
        //开始扫描 Android 5.0版本以上
        mBluetoothLeScanner.startScan(mLeScanCallback);
        //Android 5.0版本以下
        //mBluetoothAdapter.startLeScan(mLeScanCallback);
        mScanning=true;
        Setprogressbar();
        //设置自动结束扫描
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                mBluetoothLeScanner.stopScan(mLeScanCallback);
                //mBluetoothAdapter.stopLeScan(mLeScanCallback);
                mScanning=false;
                Setprogressbar();
            }
        },SCANNING_TIME);
    }
    //扫描得到结果后的回调函数
    private ScanCallback mLeScanCallback=new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            //不显示无名设备
            if (result.getDevice().getName()==null) return;
            //判断是否未初始化
            if (DeviceAddresslist == null) return;

            Bluetooth_object device_obj=new Bluetooth_object(result.getDevice().getAddress(),
                    result.getDevice().getName(),result.getDevice());
            //判断扫描到的设备是否已经存在
            if(!DeviceAddresslist.contains(device_obj.getAdress())) {
                Adapter_add(device_obj);
            }
            super.onScanResult(callbackType, result);
        }

        @Override
        public void onScanFailed(int errorCode) {
            Log.e("ScanCallback","------ScanFailed------");
            super.onScanFailed(errorCode);
        }
    };

    private void Adapter_add(Bluetooth_object device){
        DeviceAddresslist.add(device.getAdress());
        Map<String,Object> item=new HashMap<>();
        item.put(Adapteritem[0],R.mipmap.bluetooth);
        item.put(Adapteritem[1],device.getName());
        item.put(Adapteritem[2],device.getAdress());
        SimpleAdapterData.add(item);
        mAdapter.notifyDataSetChanged();
    }
    private void Device_clear(){
        DeviceAddresslist.clear();
        SimpleAdapterData.clear();
        mAdapter.notifyDataSetChanged();
    }
    private void Setprogressbar(){
        ProgressBar bar=findViewById(R.id.progressBar_scanning);
        if(mScanning){
            bar.setVisibility(ProgressBar.VISIBLE);
        }else{
            bar.setVisibility(ProgressBar.INVISIBLE);
        }
    }
}