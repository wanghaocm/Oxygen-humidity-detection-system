package com.example.common_fig;

import android.graphics.Color;
import android.os.Environment;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;

import lecho.lib.hellocharts.gesture.ContainerScrollType;
import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.ValueShape;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.LineChartView;

public class Chart_setup {

    private String title;
    private List<PointValue> values;
    private List<Line> lines;
    Line line;
    private LineChartData lineChartData;
    private LineChartView lineChartView;
    private Axis axisY, axisX;
    private float sample_rate;   //采样率
    private double maxdata;
    private double mindata;
    private Timer timer;
    float Top;
    float Bottom;
    float Left;
    float Right;
    private int max_window;
    private int save_time;

    private int max_point=2000;

    private void Chart_init(LineChartView ChartView){
        values=new ArrayList<>();
        lines=new ArrayList<>();

        lineChartView=ChartView;
        //初始化坐标轴
        axisY = new Axis();
        axisX = new Axis();

        lineChartData = new LineChartData(lines);
        lineChartData.setAxisYLeft(axisY);
        lineChartData.setAxisXBottom(axisX);

        axisY.setLineColor(Color.BLACK);
        axisY.setTextColor(Color.BLACK);
        axisY.setTextSize(21);
        axisX.setTextSize(21);
        axisX.setLineColor(Color.BLACK);
        axisX.setTextColor(Color.BLACK);

        line=new Line();
        line.setHasPoints(true);
        line.setPointRadius(4);
        line.setHasLines(true);
        line.setHasLabels(false);
        line.setHasLabelsOnlyForSelected(true);
        line.setStrokeWidth(3);
        line.setFilled(false);
        line.setCubic(false);
        line.setColor(R.color.green);
        line.setShape(ValueShape.CIRCLE);

        lineChartView.setLineChartData(lineChartData);

        lineChartView.setInteractive(true);//可交互
        lineChartView.setZoomEnabled(true);//可缩放
        lineChartView.setScrollEnabled(true);//可滚动
        lineChartView.setValueTouchEnabled(true);//可点击
        lineChartView.setViewportCalculationEnabled(true);//自动确定范围
        lineChartView.setZoomType(ZoomType.HORIZONTAL);//设置缩放模式
        lineChartView.setMaxZoom(10000);//最大缩放比,默认20
        //lineChartView.setFocusableInTouchMode(true);
        lineChartView.setContainerScrollEnabled(true, ContainerScrollType.HORIZONTAL);

        maxdata=0;
        mindata=10000;
    }

    public Chart_setup(LineChartView ChartView){
        Chart_init(ChartView);
        sample_rate=1;
        max_window=1000;
        save_time=0;
    }

    public Chart_setup(LineChartView ChartView,float rate){
        Chart_init(ChartView);
        sample_rate=rate;
        max_window=1000;
        save_time=0;
    }
    public Chart_setup(LineChartView ChartView,float rate,int window){
        Chart_init(ChartView);
        sample_rate=rate;
        max_window=window;
        save_time=0;
    }
    public void set_sample_rate(float rate){
        sample_rate=rate;
    }
    public void set_max_window(int window){
        max_window=window;
    }
    public void settitle(String name){title = name;}
//向图表添加数据
    public void addData(double num){
        maxdata=Math.max(maxdata,num);
        mindata=Math.min(mindata,num);
        PointValue point=new PointValue(values.size()/sample_rate,(float)num);
        values.add(point);
        //限制总长度
    }



    //动态刷新数据窗口
    public void refresh(){
        //if(values.size()<=1) return;

        float top=(float)maxdata*1.2f;
        float bottom=(float)mindata*0.8f;
        float right=values.get(values.size()-1).getX()+1;
        float left=values.get(Math.max(0,values.size()-max_window)).getX();
        lineChartView.setMaximumViewport(vport(top,bottom,values.get(0).getX(),right+1));

        show();
        set_port(top,bottom,left,right);
    }

    public void InitData(ArrayList<Double> num_array){
        if(num_array==null||num_array.size()==0) return;

        values.clear();
        maxdata=0;
        mindata=10000;
        int i=0;
        for(double num:num_array){
            maxdata=Math.max(maxdata,num);
            mindata=Math.min(mindata,num);
            PointValue point=new PointValue(i/(float)sample_rate, (float) num);
            values.add(point);
            i++;
        }
        lines.clear();
        //全局范围
        lineChartView.setMaximumViewport(vport((float)maxdata*1.2f,(float) mindata*0.8f,
                values.get(0).getX(),values.get(values.size()-1).getX()+3));
        init_port();
        show();
    }
    //根据范围内的数据显示内容
    private void show(){
        List<PointValue> list=new ArrayList<>();
        int step=(int)((Right-Left)*sample_rate/max_point);
        if (step==0)step++;

        for(int i=(int)(Left*sample_rate);i<values.size();i+=step){
            list.add(values.get(i));
        }

        line.setValues(list);
        if (lines.size()>1) lines.remove(0);
        lines.add(0,line);

        lineChartData = new LineChartData(lines);
        axisY.setMaxLabelChars(3);
        axisX.setMaxLabelChars(2);
        axisX.setName("Time (s)");
        lineChartData.setAxisYLeft(axisY);
        lineChartData.setAxisXBottom(axisX);
        lineChartView.setLineChartData(lineChartData);
    }

    public void Show_points(ArrayList<Integer> x_points){
        ArrayList<PointValue> Points=new ArrayList<>();
        for(int x:x_points){
            PointValue point=new PointValue(x/(float)sample_rate,values.get(x).getY());
            point.setLabel(String.valueOf(x/(float)sample_rate));
            Points.add(point);
        }
        Line line=new Line(Points);
        line.setHasPoints(true);
        line.setHasLines(false);
        line.setHasLabelsOnlyForSelected(true);
        line.setStrokeWidth(5);
        line.setPointRadius(3);
        line.setColor(Color.BLUE);
        line.setShape(ValueShape.CIRCLE);

        if (lines.size()>1) lines.remove(1);
        lines.add(line);
        lineChartData.setLines(lines);
        lineChartData.setValueLabelBackgroundAuto(false);
        lineChartData.setValueLabelBackgroundEnabled(false);
        lineChartData.setValueLabelsTextColor(Color.BLACK);
        lineChartData.setValueLabelTextSize(24);
        lineChartView.setLineChartData(lineChartData);
    }

    private Viewport vport(float top, float bottom, float left, float right){
        Viewport port=new Viewport();
        port.top=top;
        port.bottom=bottom;
        port.left=left;
        port.right=right;
        return port;
    }
    public void init_port(){
        //检验是否初始化
        if(values.size()==0)return;
        //最大同时显示10000个点
        if(values.size()>10000)
            set_port((float)maxdata*1.2f,(float) mindata*0.8f,values.get(0).getX(),values.get(9999).getX());
        else
            set_port((float)maxdata*1.2f,(float) mindata*0.8f,values.get(0).getX(),values.get(values.size()-1).getX());
    }

    public void set_port(float top, float bottom, float left, float right){
        Top=top;
        Bottom=bottom;
        Left=left;
        Right=right;
        lineChartView.setCurrentViewport(vport(top,bottom,left,right));
        show();
    }

    public float get_porttop(){
        return lineChartView.getCurrentViewport().top;
    }
    public float get_portleft(){
        return lineChartView.getCurrentViewport().left;
    }
    public float get_portright(){
        return lineChartView.getCurrentViewport().right;
    }
    public float get_portbottom(){
        return lineChartView.getCurrentViewport().bottom;
    }
    public void setaxisYName(String name) {axisY.setName(name);}
    public int getMax_window(){return max_window;}
    public List<PointValue> getValues(){
        return values;
    }

}
