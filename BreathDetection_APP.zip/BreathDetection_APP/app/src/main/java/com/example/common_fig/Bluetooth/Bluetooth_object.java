package com.example.common_fig.Bluetooth;
import android.bluetooth.BluetoothDevice;

public class Bluetooth_object {
    private String adrress;//蓝牙的地址
    private String name;//蓝牙的名字
    private BluetoothDevice device;//蓝牙的设备对象

    public Bluetooth_object(String adrress, String name, BluetoothDevice device) {
        this.adrress = adrress;
        this.name = name;
        this.device = device;
    }

    public BluetoothDevice getDevice() {
        return device;
    }

    public void setDevice(BluetoothDevice device) {
        this.device = device;
    }

    @Override
    public String toString() {
        return "BlueTooth device {" +
                "adrress='" + adrress + '\'' +
                ", name='" + name + '\'' +
                ", device=" + device +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdress() {
        return adrress;
    }

    public void setAdress(String adrress) {
        this.adrress = adrress;
    }
}
