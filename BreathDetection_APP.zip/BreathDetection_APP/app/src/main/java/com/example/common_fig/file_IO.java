package com.example.common_fig;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class file_IO {
    //读取数字数组文件并返回字符串数组
    public static String read(String filename) throws IOException {
        if (!(new File(filename).exists())){
            return null;
        }
        //打开文件输入流
        FileInputStream input;
        byte[] temp = new byte[1024];
        StringBuilder sb = new StringBuilder();
        int len;
        try {
            input = new FileInputStream(filename);
            //读取文件内容
            while ((len = input.read(temp)) > 0) {
                sb.append(new String(temp, 0, len));
            }
            input.close();
            //关闭输入
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
        return sb.toString();
    }
    //写字符串数组到文件
    public static Boolean write(String filename,String data) throws IOException {
        File file=new File(filename);
        if (!(new File(file.getParent()).exists())) {
            file.getParentFile().mkdirs();
        }
        if (!(file.exists())){
            file.createNewFile();
        }
        //打开文件输入流
        try {
            FileOutputStream output = new FileOutputStream(filename);
            //写入字符串到文件中
            output.write(data.getBytes());
            output.close();
            //关闭输入
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

        return true;
    }
    //附加字符串数组到文件
    public static Boolean append(String filename,String data) throws IOException {
        File file=new File(filename);
        if (!(new File(file.getParent()).exists())) {
            file.getParentFile().mkdirs();
        }
        if (!(file.exists())){
            new File(filename).createNewFile();
        }
        //打开文件输入流
        try {
            //追加byte到文件
            FileOutputStream output = new FileOutputStream(filename,true);
            output.write(data.getBytes());

            //追加字符串到文件中
            //FileWriter output = new FileWriter(filename,true);
            //output.write(data);

            output.close();
            //关闭输入
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

        return true;
    }
}
