#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED0 PAout(7)// PA7

void LED_Init(void);//��ʼ��

		 				    
#endif
