#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED0 PBout(11)// PB11

void LED_Init(void);//��ʼ��

		 				    
#endif
