#ifndef __BLE_H
#define __BLE_H	 
#include "sys.h"

void Ble_Init(void);

#endif
