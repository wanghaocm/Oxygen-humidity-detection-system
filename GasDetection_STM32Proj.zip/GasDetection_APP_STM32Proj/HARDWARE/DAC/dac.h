#ifndef __DAC_H
#define __DAC_H	 
#include "sys.h"	    
								    
//////////////////////////////////////////////////////////////////////////////////	 
//DAC��ʼ��������							  
//////////////////////////////////////////////////////////////////////////////////
								    

void Dac1_Init(void); //�ػ�ģʽ��ʼ��		
void Dac2_Init(void);
void Dac1_Set_Vol(u16 vol);
void Dac2_Set_Vol(u16 vol);

#endif

















