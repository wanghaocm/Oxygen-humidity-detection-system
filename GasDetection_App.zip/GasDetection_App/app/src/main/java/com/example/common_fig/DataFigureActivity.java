package com.example.common_fig;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.common_fig.Bluetooth.BluetoothLeService;
import com.example.common_fig.Bluetooth.Bluetooth_setting;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import lecho.lib.hellocharts.gesture.ContainerScrollType;
import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.listener.LineChartOnValueSelectListener;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.ValueShape;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.LineChartView;

public class DataFigureActivity extends AppCompatActivity {

    private boolean port_change_enable=true;
    Chart_setup setup;
    private int t_bias;
    private DataManager mData;


    DataManager.ParameterType parameterType;

    final static int MSG_VALUE=0x01;
    final static int MSG_TIME=0x02;
    final static int MSG_ALARM= 0x03;
    final static int MSA_NORMAL = 0x04;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_figure);
        //阻止休眠
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        //设置标题栏
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            //设置返回键
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        //actionBar.setTitle(getIntent().getExtras().get("title").toString());   //设置标题名称
        actionBar.setTitle("Current detection");   //设置标题名称
        parameterType=DataManager.string2ParameterType(getIntent().getExtras().get("title").toString());

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Permission.verifyStoragePermissions(this);

        mData=new DataManager(mHandler);
        initView();
        initTime();

        mDeviceAddress=getIntent().getStringExtra("address");
        mConnectState=getIntent().getBooleanExtra(Bluetooth_setting.CONNECT_STATE,false);
        if (mDeviceAddress!=null&&(!mDeviceAddress.equals(""))) BluetoothServiceinit();
    }
    /*-----------------------------------------------
    * 菜单
    * ----------------------------------------------*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chart_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {  //设置显示menu的图标
        if (menu != null) {
            if (menu.getClass().getSimpleName().equalsIgnoreCase("MenuBuilder")) {
                try {
                    Method method = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);
                    method.setAccessible(true);
                    method.invoke(menu, true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return super.onMenuOpened(featureId, menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case android.R.id.home:
                setup=null;
                finish();
                return false;
            case R.id.get_bluetooth_setting:
                if (mConnectState)
                    Toast.makeText(getApplicationContext(),"Bluetooth address:"+mDeviceAddress,Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(),"Bluetooth disconnected",Toast.LENGTH_SHORT).show();
                break;
            case R.id.about_author:
                Toast.makeText(getApplicationContext(),"Made by student from SYSU",Toast.LENGTH_LONG).show();
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return false;
    }
/*-----------------------------------------------
* 初始化图像
* ----------------------------------------------*/
    private void initView() {
        LineChartView lineChartView = findViewById(R.id.chart);
        setup=new Chart_setup(lineChartView,1,2500);  //sample rate为采样率
        //此处的采样率不是实际的采样率，此处的采样率*数据管理器中的平均系数才为传输的采样率
        setup.settitle(getIntent().getExtras().get("title").toString());
        TextView unit=findViewById(R.id.text_unit);
        String unitString;
        ArrayList<Double> dataList=new ArrayList<>();
        //初始化已经保存的数据并设置好坐标
        switch (parameterType){
            case NITRICOXIDE:
                unitString=mData.getUnit(DataManager.ParameterType.NITRICOXIDE);
                setup.setaxisYName("Current (μA)");
                dataList=mData.getNitricoxide();
                setup.InitData(dataList);
                unit.setText(unitString);
                break;
        }
        TextView text=findViewById(R.id.text_value);
        if(dataList.size()>0)
        text.setText(String.valueOf(String.format("%.2f",dataList.get(dataList.size()-1))));
        //保证拖动时不更新视野
        lineChartView.setOnTouchListener(new LineChartView.OnTouchListener(){
            @Override
            public boolean onTouch(View v,MotionEvent event){
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN://0
                        Log.v("CHART_TOUCH_EVENT", "LinearLayout onTouchEvent 按住");
                        port_change_enable = false;
                        break;
                    case MotionEvent.ACTION_UP://1
                        Log.v("CHART_TOUCH_EVENT", "LinearLayout onTouchEvent 抬起");
                        port_change_enable = true;
                        break;
                    case MotionEvent.ACTION_MOVE://2
                        Log.v("CHART_TOUCH_EVENT", "LinearLayout onTouchEvent 移动");
                        port_change_enable = false;
                        break;
                }
                return false;
            }
        });
        //选中数据时的响应
        lineChartView.setOnValueTouchListener(new LineChartOnValueSelectListener() {
            @Override
            public void onValueSelected(int i, int i1, PointValue pointValue) {
                float t=pointValue.getX();
                float y=pointValue.getY();

                Message msg_time=new Message();
                msg_time.what=MSG_TIME;
                msg_time.arg1=mData.getStartTime()+(int)t;
                mHandler.sendMessage(msg_time);

                Message msg_value=new Message();
                msg_value.what=MSG_VALUE;
                msg_value.arg1=(int)y;
                mHandler.sendMessage(msg_value);
            }

            @Override
            public void onValueDeselected() {

            }
        });
    }


    //设置一个初始时间
    private void initTime(){
        //计时器更新时间
        Timer timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                //更新时间
                int h= Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
                int m= Calendar.getInstance().get(Calendar.MINUTE);
                int sec=Calendar.getInstance().get(Calendar.SECOND);
                int t=h*3600+m*60+sec;
                if (t<0) t+=24*3600;
                Message msg_time=new Message();
                msg_time.what=MSG_TIME;
                msg_time.arg1=t;
                mHandler.sendMessage(msg_time);
            }
        },0,500);
    }

    private Viewport myViewport(float top, float bottom, float left, float right){
        Viewport port = new Viewport();
        port.top = top;
        port.bottom = bottom;
        port.left = left;
        port.right = right;
        return port;
    }

    //-----------------------------------------------------------------
    //以下关于蓝牙活动
    //-----------------------------------------------------------------
    private final int REQUEST_BLUETOOTHDEVICE=0;
    public void Onclick_connect(View v){
        if(!mConnectState){
            if(mDeviceAddress!=null){
                mConnectState=true;
                port_change_enable=true;
                BluetoothServiceinit();
            }
            else {
                Intent intent = new Intent(DataFigureActivity.this, Bluetooth_setting.class);
                startActivityForResult(intent, REQUEST_BLUETOOTHDEVICE);
            }
        }else{
            closebluetooth();
            port_change_enable=false;
        }
    }
    public void Onclick_big(View v){
        setup.set_max_window((int)Math.max(setup.getMax_window()*0.8,20));
    }
    public void Onclick_small(View v){
        setup.set_max_window((int)Math.min(setup.getMax_window()*1.2,10000));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_BLUETOOTHDEVICE)
            if (resultCode == Bluetooth_setting.BLUETOOTHDEVICE_RESULT) {
                if (data == null) {
                    Log.e("onActivityResult:", "Null Intent");
                    return;
                }
                mDeviceAddress = data.getStringExtra(Bluetooth_setting.DEVICE_ADDRESS);
                BluetoothServiceinit();
            }
    }
    @Override
    protected void onResume() {
        super.onResume();
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        registerReceiver(mGattUpdateReceiver, intentFilter);
    }

    @Override
    protected void onPause() {
        unregisterReceiver(mGattUpdateReceiver);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    //获取到的设备地址
    private String mDeviceAddress;
    private boolean mConnectState;
    private int Bluetooth_data=0;
    private final int CLOSEPROGRESS=0;

    private BluetoothLeService mBluetoothLeService;//服务类的对象

    private void BluetoothServiceinit(){

        Intent gattServiceIntent = new Intent(DataFigureActivity.this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
        updateShowState();
    }
    //解开与服务的绑定
    private void closebluetooth() {
        if (mBluetoothLeService != null) {
            mBluetoothLeService.close();
            unbindService(mServiceConnection);
            mBluetoothLeService = null;
        }
        mConnectState = false;
        updateShowState();
    }
    //定义连接服务
    private final ServiceConnection mServiceConnection =new ServiceConnection() {
        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {   //初始函数会返回一个值，判断有没有开蓝牙
                Log.e("DataFigureActivity:", "没有能够得到蓝牙的管理者！");
            }
            if (mBluetoothLeService != null && !mConnectState) {
                Log.e("DataFigureActivity:", "连接中...");
                //自动连接几秒后断开自动连接！
                mHandler.sendEmptyMessageDelayed(CLOSEPROGRESS, 3000);  //3秒钟后通知
                mBluetoothLeService.connect(mDeviceAddress);    //连接设备
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBluetoothLeService = null;
        }
    };

    //广播接收
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        //@TargetApi(Build.VERSION_CODES.HONEYCOMB)
        //@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();//得到广播接收器
            switch (action) {
                case BluetoothLeService.ACTION_GATT_CONNECTED://连接到蓝牙设备发送的广播！
                    Log.e("TAG", "收到蓝牙广播-------已经连接的广播！");
                    Toast.makeText(getApplicationContext(), "连接成功!", Toast.LENGTH_SHORT).show();

                    mConnectState = true;
                    updateShowState();

                    break;
                case BluetoothLeService.ACTION_GATT_DISCONNECTED:
                    Log.e("TAG", "收到蓝牙广播----断开连接的广播！");
                    Toast.makeText(getApplicationContext(), "连接已断开!", Toast.LENGTH_SHORT).show();
                    //界面改变和断开蓝牙显示
                    mConnectState = false;
                    updateShowState();
                    break;
                case BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED:
                    Log.e("TAG", "收到蓝牙广播----服务被发现的广播！");
                    break;
                case BluetoothLeService.ACTION_DATA_AVAILABLE://处理接受的数据在这里----------------------------------------------------------------------------------------------------------------
                    //Log.e("TAG", "收到蓝牙广播----收到数据的广播！");
                    //将读取到的数据进行处理操作
                    if(!port_change_enable) break;
                    String Receive_String = intent.getStringExtra(BluetoothLeService.EXTRA_DATA);
                    char[] bs = Receive_String.toCharArray();   //将输入的二进制字符串转换为字符数组，输入为0x11，输出为'1','1'
                    //存传输过来的数据
                    try{
                        int d=0;
                        int Nitricoxide =(Character.getNumericValue(bs[0]) * 16 * 16 * 16 + Character.getNumericValue(bs[1]) * 16 * 16
                                    + Character.getNumericValue(bs[2]) * 16 + Character.getNumericValue(bs[3]));
                            mData.add(Nitricoxide);

                        EditText alarm_thvalue = findViewById(R.id.th_value);
                        String thvalue = alarm_thvalue.getText().toString();
                        int alarmthvalue;
                        alarmthvalue= Integer.parseInt(thvalue);


                        if(Nitricoxide < alarmthvalue)
                        {
                            Message mas_alarm=new Message();
                            mas_alarm.what=MSG_ALARM;
                            mHandler.sendMessage(mas_alarm);
                        }else{
                            Message mas_normal=new Message();
                            mas_normal.what=MSA_NORMAL;
                            mHandler.sendMessage(mas_normal);
                        }
                    }catch (IndexOutOfBoundsException | NumberFormatException e){
                        e.printStackTrace();
                    }
                    break;

            }
        }

    };
    //更新显示状态
    private void updateShowState(){
        TextView text=findViewById(R.id.text_state);
        Button button=findViewById(R.id.button_state);
        if(mConnectState){
            //drawbyble();
            text.setText(getResources().getString(R.string.status_connected));
            button.setText(getResources().getString(R.string.disconnect));
        }else{
            text.setText(getResources().getString(R.string.status_disconnected));
            button.setText(getResources().getString(R.string.connect));
        }
    };
    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what){
                case MSG_TIME:
                    TextView clock=findViewById(R.id.Time);
                    int t,hour,min,sec;
                    t=msg.arg1;
                    hour=t/3600;
                    min=(t-hour*3600)/60;
                    sec=t-hour*3600-min*60;
                    clock.setText(" "+hour+" : ");
                    if (min<10) clock.append("0"+min); else clock.append(""+min);
                    clock.append(" : ");
                    if (sec<10) clock.append("0"+sec); else clock.append(""+sec);
                    clock.append(" ");
                    break;
                case CLOSEPROGRESS:
                    if (!mConnectState) {
                        //断开蓝牙的连接
                        closebluetooth();
                        Toast.makeText(getApplicationContext(), "连接失败!请重试", Toast.LENGTH_SHORT).show();
                    }else{
                    }
                    break;
                case DataManager.MSG_DATA:
                    TextView text=findViewById(R.id.text_value);
                    Map<DataManager.ParameterType,Double> data=(Map<DataManager.ParameterType,Double>) msg.obj;
                    Double number=data.get(parameterType);
//                  Double time=data.get()
                    text.setText(String.valueOf(String.format("%.2f",number)));
                    setup.addData(number);
                    setup.refresh();
                    break;
                case MSG_ALARM:

                    Button alarm = findViewById(R.id.gasalarm);
                    alarm.setText("ALARM");
                    alarm.setBackgroundColor(0xFFFF0000);
                    break;
                case MSA_NORMAL:
                    Button normal = findViewById(R.id.gasalarm);
                    normal.setText("NORMAL");
                    normal.setBackgroundColor(0xFF00FF00);
                    break;
            }
            return false;
        }
    });



}
