package com.example.common_fig;

import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.widget.ArrayAdapter;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class DataManager {
    public enum ParameterType {
        NITRICOXIDE;
    }
    public static ParameterType string2ParameterType(String string){
        string=string.toUpperCase();
        switch (string){
            case "NITRICOXIDE": return ParameterType.NITRICOXIDE;
        }
        return null;
    }

    private static int Nitricoxide =0;
    private static int datacount=0;

    private static Map<ParameterType,Double> messageData;

    private static int startTime;

    private static ArrayList<Double> NitricoxideArray=new ArrayList<>();
    private static ArrayList<Double> Time=new ArrayList<>();

    android.os.Handler mhandler;
    String saveDir;

    private final double average_coef=1;  //平滑点的个数

    public static final int MSG_DATA=23;

    public DataManager(Handler handler) {
        this(handler,Calendar.getInstance().get(Calendar.YEAR)+"-"
                +(Calendar.getInstance().get(Calendar.MONTH)+1)+"-"
                +Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
    }
    public DataManager(Handler handler,String savefile){
        mhandler=handler;
        setFileName(savefile);
    }

    public boolean setFileName(String dir){
        if(!dir.matches("[^.]+.csv")){
            dir=dir.concat(".csv");
        }
        boolean isSucess=true;
        saveDir= Environment.getExternalStorageDirectory().getAbsolutePath()+"/MultiParameterRecord/"+dir;
        if(!(new File(saveDir)).exists()){
            try{
                isSucess=file_IO.write(saveDir,"Nitricoxide,Sodium,PH,Uric acid,Temperature,Calcium\r\n");
            }catch (IOException e){
                e.printStackTrace();
            }
            //初始化测量时间
            int h= Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            int m= Calendar.getInstance().get(Calendar.MINUTE);
            int sec=Calendar.getInstance().get(Calendar.SECOND);
            startTime=h*3600+m*60+sec;
        }
        return isSucess;
    }
    public String getFileName(){
        File file=new File(saveDir);
        String[] name=file.getName().split(".csv");
        return name[0];
    }

    public void readFileData() throws IOException{
        clearData();
        String fileString=file_IO.read(saveDir);
        String[] fileData=fileString.split("\r\n");

        for(String line:fileData){
            try{
                String[] data=line.split(",");
                //NitricoxideArray.add(Double.parseDouble(data[0]));  //注释掉这里，后面APP就不会重新加载数据
//                Time.add(Double.parseDouble(6));
            }catch (NumberFormatException e){
                e.printStackTrace();
            }
        }

    }

    public void initDataCount(){
        Nitricoxide =0;
        datacount=0;
    }

    public void add(int nitricoxide){

        Nitricoxide +=nitricoxide ;
        datacount++;
        if(datacount>=average_coef){
            datacount=0;
            addNewData();
        }
    }

    //addNewData()函数添加数据并发送数据已更新指令到DataFigureActivity
    private void addNewData() {
        //即时保存
        try{
            file_IO.append(saveDir,Nitricoxide/average_coef+"\r\n");
        }catch (IOException e){
            e.printStackTrace();
        }
        //添加数据到数组并保存
        messageData=new HashMap<>();
        NitricoxideArray.add(Nitricoxide/average_coef);
        messageData.put(ParameterType.NITRICOXIDE,Nitricoxide/average_coef);
        Nitricoxide=0;
//        Time.add();

        Message msg=new Message();
        msg.what=MSG_DATA;
        msg.obj=messageData;
        mhandler.sendMessage(msg);
    }

    public Map<ParameterType,Double> getMessageData(){
        return messageData;
    }

    public void clearData(){
        Nitricoxide=0;
        datacount=0;

        NitricoxideArray=new ArrayList<>();
        File file=new File(saveDir);
        setFileName(file.getName());
    }

    //获取各种数据
    public ArrayList<Double> getNitricoxide(){
        return NitricoxideArray;
    }

    public double getDatacount() {
        return datacount;
    }

    public String getUnit(ParameterType type){
        String unit="";
        switch (type){
            case NITRICOXIDE:
                unit="μA";
                break;
        }
        return unit;
    }

    public int getStartTime(){
        return startTime;
    }
}
