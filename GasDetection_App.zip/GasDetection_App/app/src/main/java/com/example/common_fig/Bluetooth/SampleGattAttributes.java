package com.example.common_fig.Bluetooth;

import java.util.HashMap;

/**
 * 这个类包括一小部分标准关贸总协定属性用于演示目的。
 */
public class SampleGattAttributes {

    public static String base_uuid="-0000-1000-8000-00805f9b34fb";

    // public static String HEART_RATE_MEASUREMENT = "00002a37-0000-1000-8000-00805f9b34fb";
    //利用下面的值搞定了读写数据操作！

    //public static String HEART_RATE_MEASUREMENT = "0000ffe1-0000-1000-8000-00805f9b34fb";//这是JDY-08的使用到uuid值！其他芯片待测试！

    public static String HEART_RATE_MEASUREMENT = "0000ffe4"+base_uuid;//这是JDY-08的使用到uuid值！其他芯片待测试！

    public static String CLIENT_CHARACTERISTIC_CONFIG = "00002902"+base_uuid;

//    16位uuid转换为标准uuid格式
//    128_bit_UUID = 16_bit_UUID * 2^96 + Bluetooth_Base_UUID
//    128_bit_UUID = 32_bit_UUID * 2^96 + Bluetooth_Base_UUID

    public static String WriteGattServiceUUID="0000ffe5"+base_uuid;
    public static String WriteCharacteristicUUID="0000ffe9"+base_uuid;

    public static String ReadGattServiceUUID="0000ffe0"+base_uuid;
    public static String ReadCharacteristicUUID="0000ffe4"+base_uuid;

}
