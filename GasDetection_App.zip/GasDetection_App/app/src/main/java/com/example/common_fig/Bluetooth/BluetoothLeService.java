package com.example.common_fig.Bluetooth;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static android.content.ContentValues.TAG;

public class BluetoothLeService extends Service {
    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothGatt mBluetoothGatt;
    private String mBluetoothDeviceAddress;
    //连接状态！
    private int mConnectionState;//连接状态！
    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    public final static String ACTION_GATT_CONNECTED =
            "com.example.bluetooth.le.ACTION_GATT_CONNECTED";//已经连接的广播
    public final static String ACTION_GATT_DISCONNECTED =//断开连接的广播
            "com.example.bluetooth.le.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =//设备发现的广播
            "com.example.bluetooth.le.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =//可获得的数据的广播
            "com.example.bluetooth.le.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA =//外部数据的广播
            "com.example.bluetooth.le.EXTRA_DATA";
    //获取各种服务的特征值
    private BluetoothGattCharacteristic mNotifyCharacteristic;  //通知特征值
    //写数据
    private BluetoothGattCharacteristic characteristic;  //写特征值
    private BluetoothGattService mnotyGattService;
    //读数据
    private BluetoothGattCharacteristic readCharacteristic;  //读特征值
    private BluetoothGattService readMnotyGattService;

    /**
     * 所有连接和通信的回调都在这里！
     */
    private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i(TAG, "onConnectionStateChange");
                intentAction = ACTION_GATT_CONNECTED;
                mConnectionState = STATE_CONNECTED;
                broadcastUpdate(intentAction);//发送连接的广播！
                Log.e("TAG", "服务器的连接.");
                // 试图发现服务连接成功后。
                Log.e(TAG, "启动服务发现:" + mBluetoothGatt.discoverServices());
                //请求高优先级
                mBluetoothGatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                intentAction = ACTION_GATT_DISCONNECTED;
                mConnectionState = STATE_DISCONNECTED;
                Log.e("TAG", "服务器断开.");
                broadcastUpdate(intentAction);
            }
        }

        //发现服务回调
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            Log.e("TAG", "发现服务的回调方法执行了.....onServicesDiscovered");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG, "onServicesDiscovered");
                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
                //最最关键的就是这里了，得到服务的广播了，也就是说拿到服务了！
                //写数据的服务和characteristic
                ArrayList<BluetoothGattService> mnotyGattService=(ArrayList<BluetoothGattService>) getSupportedGattServices();
                //获取写数据特征值
                //BluetoothGattService mnotyGattService = mBluetoothLeService.getSupportedGattServices(UUID.fromString("0000ffe5-0000-1000-8000-00805f9b34fb"));
                //BluetoothGattCharacteristic characteristic = mnotyGattService.getCharacteristic(UUID.fromString("0000ffe9-0000-1000-8000-00805f9b34fb"));
                //获取读数据特征值
                readMnotyGattService = getSupportedGattServices(UUID.fromString(SampleGattAttributes.ReadGattServiceUUID));
                readCharacteristic = readMnotyGattService.getCharacteristic(UUID.fromString(SampleGattAttributes.ReadCharacteristicUUID));

                //发现服务后执行监听数据的读取操作！
                setCharacteristicNotification(readCharacteristic, true);

            } else {
                Log.e(TAG, "onservicesdiscovered收到: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            Log.e("TAG", "onCharacteristicRead-----------收到数据执行了！");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            Log.e("TAG", "onCharacteristicWrite！执行");
        }


        //收到数据回调函数
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            //Log.e("TAG", "onCharacteristicChanged-----收到数据！！");
            //正常型号蓝牙接收
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);
        }
    };

    /**
     * 初始化得到蓝牙本地的管理者！
     */
    public boolean initialize() {
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "bluetoothmanager无法初始化");
                return false;
            }
        }
        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "无法获得 ：mBluetoothAdapter");
            return false;
        }
        return true;
    }

    private final IBinder mBinder = new LocalBinder();//创建的这个属性目的就是返回一个本服务类对象！

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.e("BluetoothLeService","Bind");
        return mBinder;
    }

    public class LocalBinder extends Binder {
        //得到本服务类对象的方法！
        public BluetoothLeService getService() {
            return BluetoothLeService.this;
        }
    }

    /**
     * 连接上蓝牙LE装置关贸总协定的服务器。
     *
     * @param地址的设备地址的目的地设备。
     * @返回返回true，如果连接启动成功。连接结果 通过异步的报道
     * <p>
     * 回调。
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            Log.e(TAG, "你没有初始化或未指定的地址。");
            return false;
        }
        //以前的连接装置。尝试重新连接。
        if (mBluetoothDeviceAddress != null && address.equals(mBluetoothDeviceAddress)
                && mBluetoothGatt != null) {
            Log.e(TAG, "试图使用一个现有的mbluetoothgatt连接.");
            if (mBluetoothGatt.connect()) {
                mConnectionState = STATE_CONNECTING;
                return true;
            } else {
                return false;
            }
        }

        final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);//根据MAC地址获得蓝牙设备对象！
        if (device == null) {
            Log.e(TAG, "没有找到设备。无法连接。");
            return false;
        }
        // 我们要直接连接到设备，所以我们设置自动连接
        //mBluetoothGatt = device.connectGatt(this, true, mGattCallback);
        mBluetoothGatt = device.connectGatt(this,true,mGattCallback,BluetoothDevice.TRANSPORT_LE);
        Log.e(TAG, "试图创建一个新的连接。");
        mBluetoothDeviceAddress = address;
        mConnectionState = STATE_CONNECTING;
        //System.out.println("device.getBondState==" + device.getBondState());
        return true;
    }

    /**
     * 更新广播：封装成一个方法，就是为了方便发送广播！
     *
     * @param action 广播代号
     */
    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);
    }

    public final static UUID UUID_HEART_RATE_MEASUREMENT =
            UUID.fromString(SampleGattAttributes.HEART_RATE_MEASUREMENT);


    /**
     * 接收到的硬件传送的数据传到这里面！
     *
     * @param action
     * @param characteristic
     */
    //更新广播
    private void broadcastUpdate(final String action,
                                 final BluetoothGattCharacteristic characteristic) {
        final Intent intent = new Intent(action);
        //接收到的数据-----------------------------------------------------------------------------------------------
        //其他所有的配置文件，将数据格式化为十六进制。
        final byte[] data = characteristic.getValue();   //接受到的数据
        if (data != null && data.length > 0) {
            final StringBuilder stringBuilder = new StringBuilder(data.length);
            //把数据转化为字符串
            for (byte byteChar : data)
                stringBuilder.append(String.format("%02X", byteChar));
            String s = stringBuilder.toString();   //把数据转为字符串，发给其他控件进行处理
            intent.putExtra(EXTRA_DATA, s);// + "\n" + stringBuilder.toString());  //所有数据都转换成为字符，然后以广播的形式发出
        }
        sendBroadcast(intent);  //发送广播
    }

    /**
     * 使用给定的BLE装置后，应用程序必须调用这个方法来确保资源
     * 正确释放。
     */
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.disconnect();
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    /**
     * 断开一个现有连接或取消挂起的连接。断开的结果
     * 通过异步的报道
     * <p>
     * 回调。
     */
    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.e(TAG, "你没有初始化");
            return;
        }
        mBluetoothGatt.disconnect();
    }

    /**
     * 检索列表支持关贸总协定在连接设备上的服务。这应该是调用BluetoothGatt的方法discoverServices()}成功后执行的！
     * 获取已连接设备支持的所有GATT服务集合
     * 两种方式：一种是获取到所有的服务， 一种是根据uuid来获取指定的服务！
     */
    //得到所有用户界面上的支持服务和特征
    public List<BluetoothGattService> getSupportedGattServices() {
        if (mBluetoothGatt == null) return null;
        return mBluetoothGatt.getServices();
    }

    public BluetoothGattService getSupportedGattServices(UUID uuid) {
        BluetoothGattService mBluetoothGattService;
        if (mBluetoothGatt == null) return null;
        mBluetoothGattService = mBluetoothGatt.getService(uuid);
        return mBluetoothGattService;
    }

    /**
     * 启用或禁用通知给特性。
     *
     * @param特征值
     * @param启用 ：如果为true，启用通知。为false则不会收到通知，读写肯定得是true
     */
    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic,
                                              boolean enabled) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.e(TAG, "你没有初始化");
            return;
        }
        mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);
        String s = characteristic.getUuid().toString();
        Log.e("TAG1", "特定的心率的uuid值是：  " + s);
        Log.e("TAG1", "工具类中的心率UUID是：" + UUID_HEART_RATE_MEASUREMENT);
        // 这是特定的心脏率测量。
        if (UUID_HEART_RATE_MEASUREMENT.equals(characteristic.getUuid())) {
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(
                    UUID.fromString(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            mBluetoothGatt.writeDescriptor(descriptor);
        }
    }

    /**
     * 写出数据的操作！
     *
     * @param characteristic
     */
    public void write(BluetoothGattCharacteristic characteristic) {
        //写入指定的characteristic
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.writeCharacteristic(characteristic);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("BluetoothLeService","Created");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e("BluetoothLeService","Destroyed");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.e("BluetoothLeService","unbind");
        return super.onUnbind(intent);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e("BluetoothLeService","startcommand");
        return super.onStartCommand(intent, flags, startId);
    }
}