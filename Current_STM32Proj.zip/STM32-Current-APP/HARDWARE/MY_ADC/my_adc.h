#ifndef __MY_ADC_H
#define __MY_ADC_H

void GPIO_ADC_Init(void);
void my_ADC_Init(void);

#endif

