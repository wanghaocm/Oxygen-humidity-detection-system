#ifndef __MY_USART_H
#define __MY_USART_H

void GPIO_USART_Init(void);
void my_USART_Init(void);




#endif

