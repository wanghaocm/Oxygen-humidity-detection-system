#ifndef __MY_DMA_H
#define __MY_DMA_H

#include "stm32f10x.h"

 void DMA_TIMtoMEM_Init(void);
 //void DMA_MEMtoUSART_Init(uint32_t DMA_MemBaseAddr);


#endif

