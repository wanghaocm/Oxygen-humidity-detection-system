#ifndef __MY_TIMER_H
#define __MY_TIMER_H

void my_TIMER_Init(u16 arr,u16 psc);



#endif

