#include "stm32f10x.h"
#include "my_timer.h"
#include "my_usart.h"
 
//��ʱ����ʼ����Tout=(arr+1)(psc+1)/TCLK                      ΪʲôTCLK=72M?
//             0.5ms=( 359+1)( 99+1)/72M =360*100/72M
//               arr=359,psc=99
  void my_TIMER_Init(u16 arr,u16 psc)
 {
 
	 TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStr;
	 TIM_OCInitTypeDef TIM_OCInitStr;
	 
	 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//TIMʱ��ʹ��
	 
	 //TIM2��ʼ������
	 TIM_TimeBaseInitStr.TIM_ClockDivision=TIM_CKD_DIV1;     
	 TIM_TimeBaseInitStr.TIM_CounterMode=TIM_CounterMode_Up;  //���ϼ���
	 TIM_TimeBaseInitStr.TIM_Period=arr;      //arrΪ����ֵ
	 TIM_TimeBaseInitStr.TIM_Prescaler=psc;   //pscΪ��Ƶϵ��
   TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStr);
	 
	 //TIM2��ͨ��2���PWM����
	 TIM_OCInitStr.TIM_OCMode=TIM_OCMode_PWM1;
	 TIM_OCInitStr.TIM_OutputState=TIM_OutputState_Enable;
	 TIM_OCInitStr.TIM_Pulse=arr/2;    //��ռ�ձ�
	 TIM_OCInitStr.TIM_OCPolarity=TIM_OCPolarity_Low;
	 TIM_OC2Init(TIM2,&TIM_OCInitStr);
	 
	 //TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
	 TIM_Cmd(TIM2, ENABLE);//��TIM2
	 TIM_CtrlPWMOutputs(TIM2,ENABLE);//��TIM2���      
	 
}
 


